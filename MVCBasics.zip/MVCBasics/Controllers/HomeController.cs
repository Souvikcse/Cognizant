﻿using MVCBasics.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCBasics.Controllers
{
    public class HomeController : Controller
    {
        TruyumContext _context;
        public HomeController()
        {
            _context = new TruyumContext();
        }
        
        public ActionResult Index()
        {
            var list = _context.MenuItems.ToList();
            return View(list);
        }
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Create(MenuItem item)
        {
            _context.MenuItems.Add(item);
            _context.SaveChanges();

            return RedirectToAction("Items");
        }

        public ActionResult Items()
        {
            var list = _context.MenuItems.ToList();
            return View(list);
        }
        
    }
}