﻿using MVCBasics.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVCBasics.Controllers
{
    public class CartController : Controller
    {
        TruyumContext _context;
        public CartController()
        {
            _context = new TruyumContext();
        }
        // GET: Cart
        public ActionResult Index()
        {
            var Cartlist = _context.Cart.ToList();
            var list = new List<MenuItem>();
            foreach(var item in Cartlist)
            {
                var menuItem = _context.MenuItems.FirstOrDefault(m => m.Id == item.MenuItemId);
                if(menuItem != null)
                {
                    list.Add(menuItem);
                }
            }
            return View(list);
        }
        public ActionResult Add(int id)
        {
            Cart orderItem = new Cart()
            {
                MenuItemId = id
            };
            if (_context.Cart.FirstOrDefault(c => c.MenuItemId==id) == null)
            {
                _context.Cart.Add(orderItem);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int id)
        {
            Cart item = _context.Cart.FirstOrDefault(c => c.MenuItemId==id);
            _context.Cart.Remove(item);
            _context.SaveChanges();

            return RedirectToAction("Index");
        }
    }
}